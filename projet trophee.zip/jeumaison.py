import pygame, random


#
# Partie reactualisation de l'ecran
#
def refresh():
    global piece,jour
    ecran.fill((150,150,150))
    ecran.blit(pygame.image.load("back.png"),pygame.image.load("back.png").get_rect())
    ecran.blit(pieceobjetimg[piece][pieceobjet[piece]],pieceobjetrect[piece])
    ecran.blit(piecelumiereimg[piecelumiere[piece]],piecelumiererect)
    ecran.blit(piecevoletimg[piecevolet[piece]*(jour+1)], piecevoletrect)
    pygame.display.update()

niv2=1
#
# Partie de l'initialisation des variables
#
pygame.init()
ecran = pygame.display.set_mode((600, 600))
pygame.display.set_caption("mini jeu maison")
ecran.fill((0, 0, 255))
run = True
energie = 10000
x = 0
jour=0
decinter = 0
dec2 = 0
piecevolet = [0 for i in range(5)]
pieceobjet = [0 for i in range(5)]
piecelumiere=[0 for i in range(5)]
objeti=[150,150,75,100,75]
piecevoletimg = [pygame.image.load("fenetre"+str(i)+".png") for i in range(3)]
pieceobjetimg = [(pygame.image.load("objet"+str(i)+".png"),pygame.image.load("objet"+str(i)+"1"+".png")) for i in range(5)]
piecelumiereimg=[pygame.image.load("ampoule"+str(i)+".png") for i in range(2)]
piecevoletrect = piecevoletimg[0].get_rect().move(100,200)
pieceobjetrect = [pieceobjetimg[i][0].get_rect() for i in range(5)]
pieceobjetrect = [pieceobjetrect[i].move(((ecran.get_width()-pieceobjetrect[i].width)//2,(ecran.get_height()-pieceobjetrect[i].height-objeti[i]))) for i in range(5)]
piecelumiererect=piecelumiereimg[0].get_rect().move(250,0)
piece = 0
decrobinet =35
decjour=1500
while run:
    decjour-=1
    if decjour<=0:
        jour=abs(jour-1)
        decjour=3000
        print("ok")
    pygame.time.delay(10)
    #
    # partie changement dans les pieces
    #
    decrobinet -= 1
    if decrobinet < 0:
        decrobinet = 200
        pieceobjet[random.randint(0, 4)] = 1
    #
    # partie test des touches pressées
    #
    keys = pygame.key.get_pressed()
    if keys[pygame.K_q]:
        run = False
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    dec2 -= 1
    if keys[pygame.K_LEFT]:
        if dec2 < 0:
            piece -= 1
            dec2 = 25
            if piece < 0:
                piece = 4
    if keys[pygame.K_RIGHT]:
        if dec2 < 0:
            piece += 1
            dec2 = 25
            if piece > 4:
                piece = 0
    decinter -= 1
    if niv2:
        if keys[pygame.K_UP]:
            piecevolet[piece] = 1
        if keys[pygame.K_DOWN]:
            piecevolet[piece] = 0
    if keys[pygame.K_n]:
        if decinter < 0:
            decinter = 30
            pieceobjet[piece] = abs(pieceobjet[piece] - 1)
    if keys[pygame.K_b]:
        piecelumiere[piece]=abs(piecelumiere[piece]-1)
    refresh()
pygame.quit()
