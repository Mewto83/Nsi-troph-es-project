import
pygame
import random

#
# Partie fonction actualisation de l'ecran
#

def refresh(x, y):
    """Fonction qui fait apparaitre le jeu des panneaux solaire et le fait fonctionner en partie"""
    global decani, tapis, decaniaccele, gauche, score

    #
    # Partie animation principale
    #

    decani -= 1
    # decompte pour l'animation
    if decani <= 0:
        decani = 17
        for i in range(len(mat)):
            if mat[i][-2] <= 11:
                if verif(mat[i][-2], mat[i][0], mat[i], mat):
                    mat[i][-1] = mat[i][-1].move([10, 0])
                    mat[i][-2] += 1
        # Cette partie fait bouger chaque materiaux des tapis de gauche pouvant bouger
        for i in range(len(mat2)):
            mat2[i][-1] = mat2[i][-1].move([10, 0])
            mat2[i][-2] += 1
        # Cette partie fait bouger chaque materiaux des tapis de droite
        for i in mat2:
            if i[-2] > 15:
                if i[0] == i[1]:
                    score[1] += 1
                mat2.remove(i)
                if score[1] >= 10:
                    score[1] -= 10
                    score[0] += 1
        # Ici cette partie permet d'augmenter le score quand un materiau a bien été placé
        for i in range(len(ani)):
            ani[i] += 1
            if ani[i] >= 3:
                ani[i] = 0
                # on anime les tapis roulants et fait bouger les materiaux le long de celui ci
    # ani est un nombre pour savoir quelle image mettre pour animer les objets, decani le decompte avant le changement d 'animation

    #
    # Partie animation d'acceleration secondaire
    #

    if keys[pygame.K_SPACE]:
        decaniaccele -= 1
    if decaniaccele <= 0:
        decaniaccele = 8
        ani[tapis] += 1
        for i in range(len(mat)):
            if mat[i][0] == tapis:
                if mat[i][-2] <= 11:
                    if verif(mat[i][-2], mat[i][0], mat[i], mat):
                        mat[i][-1] = mat[i][-1].move([10, 0])
                        mat[i][-2] += 1
        for i in range(len(mat2)):
            if mat2[i][0] == tapis:
                if verif(mat2[i][-2], mat2[i][0], mat2[i], mat2):
                    mat2[i][-1] = mat2[i][-1].move([10, 0])
                    mat2[i][-2] += 1
        if random.randint(0, 26) == 25:
            if verif(mat[-1][-2], mat[-1][0], mat[-1], mat):
                mat.append([tapis, random.randint(0, 4), 0])
                mat[-1].append(imagemats[mat[-1][1]].get_rect().move([0, 100 * mat[-1][0] + 55]).move([0, mat[-1][0]]))
                if not verif(mat[-1][-2], mat[-1][0], mat[-1], mat):
                    del mat[-1]
            # on crée des materiaux suplementaire aleatoirement quand on accelere le tapis
        if ani[tapis] >= 3:
            ani[tapis] = 0
    # ici c'est un moyen d'acceler le tapis roulant en étant devant et appuyant sur espace ce qui fait apparaitre plus de materiaux

    #
    # Partie remise à zero
    #

    yconv = [(i) * 100 + 50 for i in range(5)]
    indiccouleur = [(255,255,0),(100,100,255),(255,255,255),(50,50,50),(255,0,0)]
    # je refresh mon ecran pour pas que les anciennes images restent
    ecran.fill((200, 200, 200))

    #
    #  Partie affichage des images
    #

    for i in range(5):
        pygame.draw.rect(ecran, indiccouleur[i], (450 - 12, yconv[i] - 12, 74, 74))
        # on place les indication de couleur pour savoir ou deposer les materiaux
    for i in range(5):
        ecran.blit(convs[ani[i]], convsrectg[i])
        # on place les convoyeurs de gauches
    for i in range(5):
        ecran.blit(convs[ani[i] + 3], convsrectd[i])
        # on place les convoyeurs de droite.
    for i in mat:
        ecran.blit(imagemats[i[1]], i[-1])
    for i in mat2:
        ecran.blit(imagemats[i[1]], i[-1])
    for i in range(2):
        ecran.blit(imagenombres[score[i]],imagenombres[score[i]].get_rect().move([250+i*50,-5]))
    # on place les materiaux
    # je met le carre de mon personage
    pygame.draw.rect(ecran, (0, 255, 0), (x, y, 50, 50))
    # j update mon ecran
    pygame.display.update()


#
# Partie fonction de verification
#

def verif(dist, ligne, liste, tpp):
    for i in tpp:
        if i[0] == ligne:
            if dist > (i[-2] - 3) and dist < i[-2] and not i == liste:
                return False
    return True


#
# Partie initialisation des variables
#
score = [0, 0]
ani = [0, 0, 0, 0, 0]
decani = 10
decaniaccele = 8
nommat = ("prod1.png", "prod2.png", "prod3.png", "prod4.png", "prod5.png")
imagemats = [pygame.image.load(i) for i in nommat]
nomconvs = ("conv1.png", "conv2.png", "conv3.png", "conv4.png", "conv5.png", "conv6.png")
convs = [pygame.image.load(i) for i in nomconvs]
nomnombres=("0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png",)
imagenombres=[pygame.image.load(i) for i in nomnombres]
convsrectg = [convs[0].get_rect().move([0, 50 + i * 100]) for i in range(5)]
convsrectd = [convs[0].get_rect().move([450, 50 + i * 100]) for i in range(5)]
# ici j importe les images des convoyeurs et des materiaux pour les afficher plus tard et leur positions
ecran = pygame.display.set_mode((600, 600))
# je remet la taille au cas ou
pygame.display.set_caption("Panneaux solaires")
# je met le nom
ecran.fill((200, 200, 200))
# je met la couleur de base de l ecran
run = True
gauche = 150
droite = 400
tapis = 0
x = gauche
mat = []
f = 0
dec = 0
y = tapis * 100 + 50
main = 0
mat2 = []
# j'initie toutes mes variables


#
# Grande Partie boucle
#

while run:
    #
    # Partie ajout des materiaux naturellement generés
    #

    f -= 1
    dec -= 1
    # decompte du nommbre de frames avant de pouvoir rebouger de haut en bas et celui pour faire apparaitre des materiaux
    pygame.time.delay(10)
    if dec <= 0:
        dec = 150
        mat.append([random.randint(0, 4), random.randint(0, 4), 0])
        mat[-1].append(imagemats[mat[-1][1]].get_rect().move([0, 100 * mat[-1][0] + 55]).move([0, mat[-1][0]]))
        if not verif(mat[-1][-2], mat[-1][0], mat[-1], mat):
            del mat[-1]
        # rajoute un materiau a la liste des materiaux

    #
    # Partie test des touches préssées
    #

    keys = pygame.key.get_pressed()
    # recuperation des touches pressées
    if keys[pygame.K_q]:
        # appuyer sur q termine le mini jeu
        run = False
    for event in pygame.event.get():
        # si on tente de quitter le jeu s'arette
        if event.type == pygame.QUIT:
            run = False
    if keys[pygame.K_LEFT]:
        # appuyer sur la fleche gauche nous met vers les tapis de gauche
        if x != gauche:
            if main != 0:
                main[-1] = main[-1].move([(gauche - droite), 0])
        x = gauche
    if keys[pygame.K_RIGHT]:
        # appuyer sur la fleche de droite nous met vers les tapis roulant de droite
        if x != droite:
            if main != 0:
                main[-1] = main[-1].move([(droite - gauche), 0])
        x = droite
    if keys[pygame.K_UP]:
        # appuyer sur haut nous remonte d'un tapis roulant
        if f < 0:
            if tapis > 0:
                tapis -= 1
                f = 15
                if main != 0:
                    main[-1] = main[-1].move([0, -100])
                # f est un cooldown sinon on monte de plusieurs tapis instantanément
        y = tapis * 100 + 50
    if keys[pygame.K_DOWN]:
        # à l'inverse en appuyant sur la fleche du bas on descend d'un tapis
        if f < 0:
            if tapis < 4:
                tapis += 1
                f = 15
                if main != 0:
                    main[-1] = main[-1].move([0, 100])
        y = tapis * 100 + 50
    if keys[pygame.K_n]:
        if x == gauche:
            if main == 0:
                for i in mat:
                    if i[0] == tapis:
                        if i[-2] >= 11:
                            main = i
                            mat.remove(main)
        if x == droite:
            if main != 0:
                main[-1] = main[-1].move([85, 0])
                main[-2] = 0
                main[0] = tapis
                mat2.append(main)
                if not verif(mat2[-1][-2], mat2[-1][0], mat2[-1], mat2):
                    del mat2[-1]
                else:
                    main = 0
    # la fonction pour refresh l'ecran
    refresh(x, y)
