import pygame
import random
import time

global npoub, commandscreen
#
# Partie fonction actualisation de l'ecran
#

def refresh(x, y):
    """Fonction qui fait apparaitre le jeu des dechets à la plage"""
    global npoub,commandscreen
    #
    # Partie animation principale
    #
    # decompte pour l'animation

    #
    # Partie remise à zero
    #

    yconv = [(i) * 100 + 50 for i in range(5)]
    indiccouleur = [(255,255,0),(100,100,255),(255,255,255),(50,50,50),(255,0,0)]
    # je refresh mon ecran pour pas que les anciennes images restent
    ecran.fill((255,255,0))

    #
    #  Partie affichage des images
    #

    # je met le carre de mon personage
    for i in range(2):
        ecran.blit(sable[i],sablerect[i])
    pygame.draw.rect(ecran, (0, 255, 0), (x, y, 50, 50))
    for i in range(len(dechets)):
        ecran.blit(imagedechets[dechets[i][1]],dechets[i][0])
    for i in range(2):
        ecran.blit(imagenombres[score[i]],imagenombres[score[i]].get_rect().move([250+i*50,-5]))
    # on place les dechets
    ecran.blit(pygame.transform.scale(imagedechets[npoub],[70,70]),pygame.Rect(0,ecran.get_width()-70,70,70))
    #on place l'indicateur de la poubelle que l'on a prise


    #
    #Partie ecran de pause
    #
    if pausvalue[1]:
        ecran.fill((200, 200, 200))
        for i in range(3):
            ecran.blit(spritesbutton[i], spriterectbuttons[i])
    #
    # partie ecran des commandes
    #
    if not pausvalue[2]:
        ecran.fill((255,255,255))
        ecran.blit(commandscreen,commandscreen.get_rect())
    # j update mon ecran
    pygame.display.update()




#
# Partie initialisation des variables
#
score = [0, 0]
pausvalue=[True,True,True]
ecran = pygame.display.set_mode((600, 600))
decani = 10
decaniaccele = 8
spritesbutton=[pygame.image.load("closebutton.png"),pygame.image.load("pausebutton.png"),pygame.image.load("commandbutton.png")]
spriterect=[i.get_rect() for i in spritesbutton]
spriterectbuttons=[spriterect[i].move(((ecran.get_width()-spriterect[i].width)/2-200+200*i,(ecran.get_height()-spriterect[i].height)/2)) for i in range(3)]
nomdechets = ("plastique.png","metal.png","papier.png","organique.png")
imagedechets = [pygame.image.load(i) for i in nomdechets]
nomnombres=("0.png","1.png","2.png","3.png","4.png","5.png","6.png","7.png","8.png","9.png",)
imagenombres=[pygame.image.load(i) for i in nomnombres]
commandscreen=pygame.image.load("ecrancommandmer.png")
sable=[pygame.image.load("sable"+str(i)+".png") for i in range(2)]
sablerect=[sable[i].get_rect().move(0,i*600) for i in range(2)]
# ici j importe les images des convoyeurs et des materiaux pour les afficher plus tard et leur positions
pygame.display.set_caption("nettoyage de plage")
# je met le nom
ecran.fill((200, 200, 200))
# je met la couleur de base de l ecran
run = True
tapis = 0
x = 250
dechets = []
npoub=0
poubelles=[[],[],[]]
f = 0
dec = 0
y = 250
main = 0
mat2 = []
decpaus=0
decmove=1
# j'initie toutes mes variables


#
# Grande Partie boucle
#
timed=time.process_time()
while run:
    timef=time.process_time()-timed
    if timef>=100:
        run=False
    perso=pygame.Rect(x,y,50,50)
    refresh(x, y)
    #
    #partie menu pause
    #
    if pausvalue[1]:
        for e in range(len(pausvalue)):
            if pygame.mouse.get_pressed()[0] and spriterectbuttons[e].collidepoint(pygame.mouse.get_pos()):
                pausvalue[e]=False
                if e==2:
                    pausvalue[1]=True
        run=pausvalue[0]
    if not pausvalue[1] and pausvalue[2]:
        dec-=1
        decmove-=1
    #
    # Partie ajout des dechets naturellement generés
    #
    pygame.time.delay(10)
    if dec <= 0:
        dec = random.randint(150,300)
        for i in range(random.randint(1,3)):
            dechets.append([pygame.Rect(random.randint(10,560),-110,20,20),random.randint(0,3)])
        # rajoute un/des dechets a la liste des materiaux

    if decmove<=0:
        decmove=1
        for i in sablerect:
            if i.y>600:
                i.y=-600
            i.y+=1
        for i in dechets:
            i[0]=i[0].move(0,1)
            if i[0].y>600:
                dechets.remove(i)
    #
    # Partie test des touches préssées
    #
    keys = pygame.key.get_pressed()
    # recuperation des touches pressées
    if keys[pygame.K_q]:
        # appuyer sur q termine le mini jeu
        run = False
    if keys[pygame.K_ESCAPE]:
        #
        # variable pour le menu de pause
        #
        pausvalue[1]=True
        pausvalue[2]=True
        pygame.time.delay(100)
    for event in pygame.event.get():
        # si on tente de quitter le jeu s'arette
        if event.type == pygame.QUIT:
            run=False
    if keys[pygame.K_a]:
        npoub=0
        #choisit la poubelle utilisée sur plastique
    if keys[pygame.K_z]:
        npoub=1
        # choisit la poubelle utilisée sur metal
    if keys[pygame.K_e]:
        npoub=2
        # choisit la poubelle utilisée sur papier
    if keys[pygame.K_r]:
        npoub=3
        # choisit la poubelle utilisée sur organique
    if keys[pygame.K_LEFT]:
        # appuyer sur la fleche gauche nous met vers les tapis de gauche
        if x>0:
            x-=2
    if keys[pygame.K_RIGHT]:
        # appuyer sur la fleche de droite nous met vers les tapis roulant de droite
        if x<ecran.get_width()-50:
            x+=2
    if keys[pygame.K_UP]:
        # appuyer sur haut nous bouge vers le haut
        if y>0:
            y-=2
    if keys[pygame.K_DOWN]:
        # à l'inverse en appuyant sur la fleche du bas vas vers le bas
        if y<ecran.get_height()-50:
            y+=2
    if keys[pygame.K_n]:
        for i in dechets:
            if perso.colliderect(i[0]) and i[-1]==npoub:
                dechets.remove(i)
                score[1]+=1
                if score[1]>=10:
                    score[1]-=10
                    score[0]+=1
scoref=score[0]*10+score[1]